package com.mosely.weightapp;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class HomeActivity extends AppCompatActivity {

    EditText goalWeightEditText, dailyWeightEditText, numberEditText;
    Button enableNotificationsButton;
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    Button saveButton;
    DBHelper dbHelper;
    TableLayout weightTable;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        numberEditText = findViewById(R.id.numberEditText);
        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        dailyWeightEditText = findViewById(R.id.dailyWeightEditText);
        saveButton = findViewById(R.id.saveButton);
        weightTable = findViewById(R.id.weightTable);
        dbHelper = new DBHelper(this);

        String username = getIntent().getStringExtra("username");
        userId = dbHelper.getUserId(username);

        enableNotificationsButton = findViewById(R.id.enableNotificationsButton);
        enableNotificationsButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                checkSMSPermission();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double goalWeight = Double.parseDouble(goalWeightEditText.getText().toString());
                    double dailyWeight = Double.parseDouble(dailyWeightEditText.getText().toString());
                    double phoneNumber = Double.parseDouble(numberEditText.getText().toString());
                    String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    if (dbHelper.insertWeight(userId, goalWeight, date, dailyWeight)) {
                        Toast.makeText(HomeActivity.this, "Saved successfully!", Toast.LENGTH_SHORT).show();
                        checkGoalWeight(goalWeight, dailyWeight, phoneNumber);
                        updateGrid();
                    } else {
                        Toast.makeText(HomeActivity.this, "Save failed", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(HomeActivity.this, "Please enter valid weights", Toast.LENGTH_SHORT).show();
                }

            }
        });

        updateGrid();
    }

    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permissions Granted", Toast.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private void checkGoalWeight(double dailyWeight, double goalWeight, double phoneNumber) {
        if (dailyWeight == goalWeight) {
            Toast.makeText(this, "Congrats ! You met your weight goal of " + goalWeight, Toast.LENGTH_SHORT).show();
            sendSMS(String.valueOf(phoneNumber), "Congrats! You met your goal weight of " + goalWeight);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, handle notifications
            } else {
                // Permission denied, you can handle it based on your app's requirement
                Toast.makeText(this, "Permission denied. Cannot provide notifications.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    @SuppressLint({"Range", "SetTextI18n"})
    private void updateGrid() {
        Cursor cursor = dbHelper.getWeights(userId);
        int count = weightTable.getChildCount();
        for (int i = 1; i < count; i++) {
            weightTable.removeViewAt(1);
        }

        while (cursor.moveToNext()) {
            TableRow row = new TableRow(this);

            EditText dateEditText = new EditText(this);
            dateEditText.setText(cursor.getString(cursor.getColumnIndex(DBHelper.COLUMN_DATE)));
            dateEditText.setPadding(4, 8, 4, 8);
            row.addView(dateEditText);

            EditText goalWeightEditText = new EditText(this);
            goalWeightEditText.setText(Double.toString(cursor.getDouble(cursor.getColumnIndex(DBHelper.COLUMN_GOAL_WEIGHT))));
            goalWeightEditText.setPadding(4, 8, 4, 8);
            goalWeightEditText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            row.addView(goalWeightEditText);

            EditText dailyWeightEditText = new EditText(this);
            dailyWeightEditText.setText(Double.toString(cursor.getDouble(cursor.getColumnIndex(DBHelper.COLUMN_DAILY_WEIGHT))));
            dailyWeightEditText.setPadding(4, 8, 4, 8);
            dailyWeightEditText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            row.addView(dailyWeightEditText);

            Button updateButton = new Button(this);
            updateButton.setText("Update");
            final int weightId = cursor.getInt(cursor.getColumnIndex("ID"));
            updateButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String newDate = dateEditText.getText().toString();
                    double newGoalWeight = Double.parseDouble(goalWeightEditText.getText().toString());
                    double newDailyWeight = Double.parseDouble(dailyWeightEditText.getText().toString());

                    dbHelper.updateWeight(weightId, newGoalWeight, newDate, newDailyWeight);
                    updateGrid();
                    Toast.makeText(HomeActivity.this, "Updated successfully!", Toast.LENGTH_SHORT).show();
                }
            });
            row.addView(updateButton);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dbHelper.deleteWeight(weightId);
                    updateGrid();
                    Toast.makeText(HomeActivity.this, "Deleted successfully!", Toast.LENGTH_SHORT).show();
                }
            });
            row.addView(deleteButton);

            weightTable.addView(row);
        }

        cursor.close();
    }

    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS sent successfully.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS sending failed. Please try again.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

}
