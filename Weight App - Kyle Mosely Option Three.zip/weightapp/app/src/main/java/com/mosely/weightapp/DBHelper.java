package com.mosely.weightapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "users";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String WEIGHT_TABLE_NAME = "weightTracking";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_DAILY_WEIGHT = "daily_weight";

    public DBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUserTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD + " TEXT)";
        String createWeightTable = "CREATE TABLE " + WEIGHT_TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USER_ID + " INTEGER, " + COLUMN_GOAL_WEIGHT + " REAL, " + COLUMN_DATE + " TEXT, " + COLUMN_DAILY_WEIGHT + " REAL)";
        db.execSQL(createUserTable);
        db.execSQL(createWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + WEIGHT_TABLE_NAME);
        onCreate(db);
    }

    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?", new String[]{username, password});
        return cursor.getCount() > 0;
    }

    public boolean insertWeight(int userId, double goalWeight, String date, double dailyWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USER_ID, userId);
        contentValues.put(COLUMN_GOAL_WEIGHT, goalWeight);
        contentValues.put(COLUMN_DATE, date);
        contentValues.put(COLUMN_DAILY_WEIGHT, dailyWeight);
        long result = db.insert(WEIGHT_TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public void deleteWeight(int weightId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(WEIGHT_TABLE_NAME, "ID=?", new String[]{String.valueOf(weightId)});

    }

    public void updateWeight(int weightId, double goalWeight, String date, double dailyWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_GOAL_WEIGHT, goalWeight);
        contentValues.put(COLUMN_DATE, date);
        contentValues.put(COLUMN_DAILY_WEIGHT, dailyWeight);
        db.update(WEIGHT_TABLE_NAME, contentValues, "ID = ?", new String[]{String.valueOf(weightId)});
    }

    public Cursor getWeights(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT ID as _id, * FROM " + WEIGHT_TABLE_NAME + " WHERE " + COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    public int getUserId(String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT ID FROM " + TABLE_NAME + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});
        if (cursor.moveToFirst()) {
            return cursor.getInt(0);
        }
        return -1;
    }
}

